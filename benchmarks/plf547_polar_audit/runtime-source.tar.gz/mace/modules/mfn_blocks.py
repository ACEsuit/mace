import numpy as np
import torch
import torch.nn.functional
from abc import ABC, abstractmethod
from typing import Optional, Tuple

from e3nn import nn, o3
from e3nn.util.jit import compile_mode
from scipy.linalg import eigh_tridiagonal

from mace.tools.torch_geometric.utils import to_dense_adj, to_dense_batch
from mace.tools.torch_tools import get_mask

from mace.modules.wrapper_ops import (
    CuEquivarianceConfig,
    FullyConnectedTensorProduct,
    Linear,
    TensorProduct,
)

from .irreps_tools import (
    tp_out_irreps_with_instructions,
)


class AbstractMatrixFunctionBlock(torch.nn.Module, ABC):
    """
    Abstract base class for matrix function blocks.
    
    Matrix function blocks construct a matrix representation of the system and
    apply a function to this matrix, producing node features.
    """
    
    def __init__(
        self,
        node_feats_irreps: o3.Irreps,
        num_features: int,
        num_basis: int,
        num_poles: int,
        sh_irreps: o3.Irreps,
        num_elements: int,
        interaction_irreps: o3.Irreps,
        avg_num_neighbors: float,
        irreps_matrix_basis: o3.Irreps,
        cueq_config: Optional[CuEquivarianceConfig] = None,
    ):
        super().__init__()
        self.node_feats_irreps = node_feats_irreps
        self.num_features = num_features
        self.num_poles = num_poles
        self.avg_num_neighbors = avg_num_neighbors
        self.irreps_matrix_basis = irreps_matrix_basis
        self.cueq_config = cueq_config
        
        # Linear transformation for node features
        self.linear_up = Linear(
            self.node_feats_irreps,
            self.node_feats_irreps,
            internal_weights=True,
            shared_weights=True,
            cueq_config=cueq_config,
        )
        
        # Matrix construction blocks
        self.off_matrix_construction = OffDiagMatrixConstructionBlock(
            node_feats_irreps=node_feats_irreps,
            interaction_irreps=interaction_irreps,
            num_features=num_features,
            num_basis=num_basis,
            num_poles=num_poles,
            sh_irreps=sh_irreps,
            avg_num_neighbors=avg_num_neighbors,
            irreps_matrix_basis=irreps_matrix_basis,
            cueq_config=cueq_config,
        )
        
        self.diagonal_matrix_construction = DiagMatrixConstructionBlock(
            node_feats_irreps=node_feats_irreps,
            num_features=num_features,
            num_poles=num_poles,
            irreps_matrix_basis=irreps_matrix_basis,
            num_elements=num_elements,
            cueq_config=cueq_config,
        )
        
        # Utility functions for matrix operations
        self.extract_block = extract_blocks(irreps_matrix_basis)
        self.fill = fill_blocks(irreps_matrix_basis)
    
    @abstractmethod
    def apply_matrix_function(
        self, 
        H_dense: torch.Tensor, 
        diag_H_shape: int, 
        node_feats: torch.Tensor, 
        ptr: torch.Tensor,
        fermi_level: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Apply the matrix function to the Hamiltonian matrix.
        
        Args:
            H_dense: Dense Hamiltonian matrix
            diag_H_shape: Shape of diagonal elements
            node_feats: Node features
            ptr: Pointer to batch elements
            fermi_level: Optional Fermi level
            
        Returns:
            out: Node features after applying the matrix function
            features_full: Full feature matrix
            density_matrix: Density matrix
        """
        pass
    
    def forward(
        self,
        node_feats: torch.Tensor,
        node_attrs: torch.Tensor,
        edge_feats: torch.Tensor,
        edge_attrs: torch.Tensor,
        edge_index: torch.Tensor,
        batch: torch.Tensor,
        ptr: torch.Tensor,
        matrix_feats: Optional[torch.Tensor] = None,
        fermi_level: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Forward pass through the matrix function block.
        
        Args:
            node_feats: Node features
            node_attrs: Node attributes
            edge_feats: Edge features
            edge_attrs: Edge attributes
            edge_index: Edge indices
            batch: Batch indices
            ptr: Pointer to batch elements
            matrix_feats: Optional matrix features from previous layer
            fermi_level: Optional Fermi level
            
        Returns:
            out: Node features after applying the matrix function
            features_full: Full feature matrix
            H_dense: Dense Hamiltonian matrix
            density_matrix: Density matrix
        """
        # Apply linear transformation to node features
        node_feats = self.linear_up(node_feats)
        
        # Construct off-diagonal and diagonal elements of the Hamiltonian
        H_dense_off = self.off_matrix_construction(node_feats, edge_feats, edge_attrs, edge_index, batch)
        diag_H = self.diagonal_matrix_construction(node_feats, node_attrs, batch)
        
        # Combine into full Hamiltonian matrix
        H_dense = self.fill(H_dense_off, diag_H)
        
        # If matrix features from previous layer provided, add them
        if matrix_feats is not None:
            H_dense = H_dense + matrix_feats
        
        # Apply matrix function to Hamiltonian
        out, features_full, density_matrix = self.apply_matrix_function(
            H_dense, diag_H.shape[-1], node_feats, ptr, fermi_level
        )
        
        return out, features_full, H_dense, density_matrix


@compile_mode("script")
class ScalarMatrixFunctionBlock(AbstractMatrixFunctionBlock):
    """
    Matrix function block that uses scalar diagonalization.
    
    This block computes eigenvalues of the Hamiltonian and applies a 
    learned function to them.
    """
    
    def __init__(
        self,
        node_feats_irreps: o3.Irreps,
        num_features: int,
        num_basis: int,
        num_poles: int,
        sh_irreps: o3.Irreps,
        num_elements: int,
        interaction_irreps: o3.Irreps,
        avg_num_neighbors: float,
        irreps_matrix_basis: o3.Irreps,
        subspace_dim: Optional[int] = None,
        cueq_config: Optional[CuEquivarianceConfig] = None,
    ):
        super().__init__(
            node_feats_irreps=node_feats_irreps,
            num_features=num_features,
            num_basis=num_basis,
            num_poles=num_poles,
            sh_irreps=sh_irreps,
            num_elements=num_elements,
            interaction_irreps=interaction_irreps,
            avg_num_neighbors=avg_num_neighbors,
            irreps_matrix_basis=irreps_matrix_basis,
            cueq_config=cueq_config,
        )
        
        self.subspace_dim = subspace_dim
        self.matrix_norm = EigenvalueBatchNorm(num_features * num_poles)
        
        # MLP to transform eigenvalues
        self.mfn_mlp = nn.FullyConnectedNet(
            [num_features * num_poles] + 3 * [64] + [num_features * num_poles],
            torch.nn.functional.silu,
        )
        
        # Output linear transformation
        self.linear_out = Linear(
            o3.Irreps(f"{num_features * num_poles}x0e"),
            self.node_feats_irreps,
            internal_weights=True,
            shared_weights=True,
            cueq_config=cueq_config,
        )
    
    def apply_matrix_function(
        self, 
        H_dense: torch.Tensor, 
        diag_H_shape: int, 
        node_feats: torch.Tensor, 
        ptr: torch.Tensor,
        fermi_level: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Apply scalar matrix function using eigendecomposition."""
        mask = get_mask(ptr[1:] - ptr[:-1]).to(node_feats.device)
        mask_matrix = mask.reshape(
            (ptr[1:] - ptr[:-1]).shape[0],
            (ptr[1:] - ptr[:-1]).max())
        mask_matrix = mask_matrix.unsqueeze(-1).repeat(1, 1, diag_H_shape).reshape(mask_matrix.shape[0], -1)
        
        # Normalize matrix
        H_dense_normalized = H_dense
        
        # Compute eigenvalues
        if self.subspace_dim is not None:
            _, eigenvalues = low_rank_eigen_svd(H_dense_normalized, q=self.subspace_dim, niter=2)
        else:
            eigenvalues = torch.linalg.eigvalsh(H_dense_normalized).permute(0, 2, 1)
        
        # Apply learned transformation to eigenvalues
        mfn_eigenvalues = self.mfn_mlp(eigenvalues)
        features = (eigenvalues * mfn_eigenvalues)
        
        # Construct density matrix and full features
        density_matrix = torch.diag_embed(mfn_eigenvalues.permute(0, 2, 1))
        features_full = torch.diag_embed(features.permute(0, 2, 1))
        
        # Extract per-node features
        num_nodes = mask.shape[0] // features.shape[0]
        features = features.reshape(features.shape[0], num_nodes, self.irreps_matrix_basis.dim, -1).sum(2)
        features = features.reshape(features.shape[0]*features.shape[1], -1)
        
        # Apply output transformation
        out = self.linear_out(features[mask]) / self.avg_num_neighbors
        
        return out, features_full, density_matrix


@compile_mode("script")
class ResolventMatrixFunctionBlock(AbstractMatrixFunctionBlock):
    """
    Matrix function block that applies the resolvent function.
    
    This block computes (z*I - H)^(-1) and extracts features from it.
    """
    
    def __init__(
        self,
        node_feats_irreps: o3.Irreps,
        num_features: int,
        num_basis: int,
        num_poles: int,
        sh_irreps: o3.Irreps,
        num_elements: int,
        interaction_irreps: o3.Irreps,
        avg_num_neighbors: float,
        irreps_matrix_basis: o3.Irreps,
        cueq_config: Optional[CuEquivarianceConfig] = None,
    ):
        super().__init__(
            node_feats_irreps=node_feats_irreps,
            num_features=num_features,
            num_basis=num_basis,
            num_poles=num_poles,
            sh_irreps=sh_irreps,
            num_elements=num_elements,
            interaction_irreps=interaction_irreps,
            avg_num_neighbors=avg_num_neighbors,
            irreps_matrix_basis=irreps_matrix_basis,
            cueq_config=cueq_config,
        )
        
        # Output irreps setup
        self.irreps_matrix_block = self.diagonal_matrix_construction.irreps_matrix_block
        irreps_out = o3.Irreps(
            (num_features * num_poles * self.irreps_matrix_block)
            .sort()
            .irreps.simplify()
        )
        self.unreshape_irreps = unreshape_irreps_blocks(self.irreps_matrix_block)
        
        # Output linear transformation
        self.linear_out = Linear(
            irreps_out,
            self.node_feats_irreps,
            internal_weights=True,
            shared_weights=True,
            cueq_config=cueq_config,
        )
    
    def apply_matrix_function(
        self, 
        H_dense: torch.Tensor, 
        diag_H_shape: int, 
        node_feats: torch.Tensor, 
        ptr: torch.Tensor,
        fermi_level: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Apply resolvent matrix function using matrix inversion."""
        mask = get_mask(ptr[1:] - ptr[:-1]).to(node_feats.device)
        
        # Create matrix with imaginary diagonal
        D_z = torch.diag_embed(1j * torch.ones_like(H_dense[..., 0]))
        R_dense = D_z - H_dense
        
        # Compute LU factorization for matrix inversion
        LUP = torch.linalg.lu_factor_ex(R_dense)
        LU, P = LUP.LU, LUP.pivots
        
        # Get identity matrix for resolvent computation
        R_dense_shape = R_dense.shape
        identity = (
            torch.eye(R_dense_shape[-1], dtype=D_z.dtype, device=D_z.device)
            .unsqueeze(0)
            .repeat(*R_dense_shape[:-2], 1, 1)
        )
        
        # Compute density matrix from resolvent's imaginary part
        density_matrix = torch.linalg.lu_solve(LU, P, identity).imag
        
        # Extract features from H*density_matrix
        features_full = torch.einsum("...jk,...kl->...jl", H_dense, density_matrix).mean(1)
        features_full = features_full.flatten(1, 2)
        features = self.extract_block(features_full)
        features = features.reshape(features.shape[0]*features.shape[1], features.shape[2], features.shape[3])
        
        # Apply to nodes and transform output
        node_features = features.real[mask, :, :] / self.avg_num_neighbors
        node_features = self.unreshape_irreps(node_features)
        out = self.linear_out(node_features)
        
        return out, features_full, density_matrix


@compile_mode("script")
class FermiDiracSquareBlock(AbstractMatrixFunctionBlock):
    """
    Matrix function block that applies Fermi-Dirac statistics using 
    a squared rational expansion approach.
    """
    
    def __init__(
        self,
        node_feats_irreps: o3.Irreps,
        num_features: int,
        num_basis: int,
        num_poles: int,
        sh_irreps: o3.Irreps,
        num_elements: int,
        interaction_irreps: o3.Irreps,
        avg_num_neighbors: float,
        irreps_matrix_basis: o3.Irreps,
        cueq_config: Optional[CuEquivarianceConfig] = None,
    ):
        super().__init__(
            node_feats_irreps=node_feats_irreps,
            num_features=num_features,
            num_basis=num_basis,
            num_poles=num_poles,
            sh_irreps=sh_irreps,
            num_elements=num_elements,
            interaction_irreps=interaction_irreps,
            avg_num_neighbors=avg_num_neighbors,
            irreps_matrix_basis=irreps_matrix_basis,
            cueq_config=cueq_config,
        )
        
        # Compute poles and residues for rational expansion
        poles, residues = self._poles_and_residues(cutoff=num_poles)
        self.register_buffer("poles", poles)
        self.register_buffer("residues", residues)
        
        # Output linear transformation (scalar-only for Fermi-Dirac)
        self.linear_out = Linear(
            o3.Irreps(f"{num_features * num_poles}x0e"),
            self.node_feats_irreps,
            internal_weights=True,
            shared_weights=True,
            cueq_config=cueq_config,
        )
    
    def _poles_and_residues(self, cutoff: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute poles and residues for the rational expansion."""
        j = np.arange(cutoff-1)
        b_mat = 1 / (2.0 * np.sqrt((2*(j+1) - 1)*(2*(j+1) + 1)))
        poles, residues = eigh_tridiagonal(np.zeros((len(b_mat) + 1,)), b_mat)
        residues = 0.25 * np.array([np.abs(residues[0, j])**2 / (poles[j] ** 2) for j in range(residues.shape[0])])
        return 1 / (torch.tensor(poles) ** 2), torch.tensor(residues)
    
    def apply_matrix_function(
        self, 
        H_dense: torch.Tensor, 
        diag_H_shape: int, 
        node_feats: torch.Tensor, 
        ptr: torch.Tensor,
        fermi_level: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Apply Fermi-Dirac statistics using rational expansion."""
        if fermi_level is not None:
            mu = fermi_level
        else:
            mu = torch.tensor([0.0], device=H_dense.device, dtype=H_dense.dtype)
            mu = mu.repeat(H_dense.shape[0])
        
        # Get mask for nodes
        mask = get_mask(ptr[1:] - ptr[:-1]).to(H_dense.device)
        
        # Create chemical potential diagonal matrix
        kbT = 0.1  # Temperature parameter
        mu_diag = torch.einsum("b, ij->bij", mu, torch.eye(H_dense.shape[-1], device=H_dense.device))
        view_mu_diag_shape = (mu_diag.shape[0],) + (1,) * (H_dense.dim() - mu_diag.dim()) + mu_diag.shape[-2:]
        mu_diag = mu_diag.view(*view_mu_diag_shape)
        
        # Prepare poles for computation
        self.poles = self.poles.type_as(H_dense)
        self.residues = self.residues.type_as(H_dense)
        poles = self.poles.unsqueeze(-1).repeat(1, H_dense.shape[-1])
        poles = torch.diag_embed(poles)
        view_poles_shape = (1,) * (H_dense.dim() - poles.dim()) + poles.shape[-3:]
        poles = poles.view(*view_poles_shape)
        
        # Compute R_input = (H - μI) / kbT
        R_input = (1/kbT) * (H_dense - mu_diag)
        
        # Square R_input and add poles
        R_square = torch.einsum("...jk,...kl->...jl", R_input, R_input)
        R_dense = R_square + poles
        
        # Compute inverse of R_dense
        R_dense_shape = R_dense.shape
        LUP = torch.linalg.lu_factor_ex(R_dense)
        LU, P = LUP.LU, LUP.pivots
        identity = (
            torch.eye(R_dense_shape[-1], dtype=R_dense.dtype, device=R_dense.device)
            .unsqueeze(0)
            .repeat(*R_dense_shape[:-2], 1, 1)
        )
        R_inv = torch.linalg.lu_solve(LU, P, identity)
        
        # Apply residues to inverse matrices
        R_weighted = torch.einsum("p,...pkl->...kl", self.residues, R_inv)
        
        # Multiply by R_input to get final result
        R_m = torch.einsum("...jk, ...kl->...jl", R_weighted, R_input[...,0,:,:])
        
        # Construct density matrix
        density_matrix = torch.eye(H_dense.shape[-1], device=R_dense.device) - 2 * R_m.real
        
        # Extract features from H*density_matrix
        features_full = torch.einsum("...jk,...kl->...jl", H_dense[...,0,:,:], density_matrix).mean(1, keepdim=True)
        features = extract_sum_of_diagonals(features_full, self.irreps_matrix_basis.dim)
        features = features.reshape(features.shape[0]*features.shape[1], -1).sum(-1)
        
        # Apply to node features
        out = features[mask] / self.avg_num_neighbors
        
        return out, features_full, density_matrix


@compile_mode("script")
class MatrixFunctionBlock(torch.nn.Module):
    """
    Original MatrixFunctionBlock implementation, maintained for compatibility.
    This delegates to the appropriate specialized implementation based on parameters.
    """
    
    def __init__(
        self,
        node_feats_irreps: o3.Irreps,
        num_features: int,
        num_basis: int,
        num_poles: int,
        sh_irreps: o3.Irreps,
        num_elements: int,
        interaction_irreps: o3.Irreps,
        avg_num_neighbors: float,
        irreps_matrix_basis: o3.Irreps,
        use_matrix_function: bool = True,
        use_fermi_dirac: bool = False,
        scalar_only: bool = False,
        subspace_dim: Optional[int] = None,
        cueq_config: Optional[CuEquivarianceConfig] = None,
    ):
        super().__init__()
        
        # Create the appropriate implementation based on parameters
        if use_fermi_dirac:
            self.implementation = FermiDiracSquareBlock(
                node_feats_irreps=node_feats_irreps,
                num_features=1,  # Fermi-Dirac uses 1 feature
                num_basis=num_basis,
                num_poles=64,  # Fermi-Dirac uses fixed 64 poles
                sh_irreps=sh_irreps,
                num_elements=num_elements,
                interaction_irreps=interaction_irreps,
                avg_num_neighbors=avg_num_neighbors,
                irreps_matrix_basis=irreps_matrix_basis,
                cueq_config=cueq_config,
            )
            # Optional weights for scaling
            if use_matrix_function:
                self.weights_sc = torch.nn.Parameter(torch.randn(num_features * num_poles, num_poles))
        elif scalar_only:
            self.implementation = ScalarMatrixFunctionBlock(
                node_feats_irreps=node_feats_irreps,
                num_features=num_features,
                num_basis=num_basis,
                num_poles=num_poles,
                sh_irreps=sh_irreps,
                num_elements=num_elements,
                interaction_irreps=interaction_irreps,
                avg_num_neighbors=avg_num_neighbors,
                irreps_matrix_basis=irreps_matrix_basis,
                subspace_dim=subspace_dim,
                cueq_config=cueq_config,
            )
        else:
            self.implementation = ResolventMatrixFunctionBlock(
                node_feats_irreps=node_feats_irreps,
                num_features=num_features,
                num_basis=num_basis,
                num_poles=num_poles,
                sh_irreps=sh_irreps,
                num_elements=num_elements,
                interaction_irreps=interaction_irreps,
                avg_num_neighbors=avg_num_neighbors,
                irreps_matrix_basis=irreps_matrix_basis,
                cueq_config=cueq_config,
            )
        
        self.use_matrix_function = use_matrix_function
        self.use_fermi_dirac = use_fermi_dirac
        self.num_poles = num_poles
        self.num_features = num_features

    def forward(
        self,
        node_feats: torch.Tensor,
        node_attrs: torch.Tensor,
        edge_feats: torch.Tensor,
        edge_attrs: torch.Tensor,
        edge_index: torch.Tensor,
        batch: torch.Tensor,
        ptr: torch.Tensor,
        matrix_feats: Optional[torch.Tensor] = None,
        fermi_level: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Forward pass through the matrix function block, delegating to the appropriate implementation.
        """
        # If using FermiDirac with SC weights
        if self.use_fermi_dirac and hasattr(self, 'weights_sc') and matrix_feats is not None:
            # Apply SC weights before passing to implementation
            out, features_full, H_dense, density_matrix = self.implementation(
                node_feats, node_attrs, edge_feats, edge_attrs, edge_index, batch, ptr, matrix_feats, fermi_level
            )
            
            # Scale using weights_sc if needed
            if features_full is not None and self.use_matrix_function:
                H_dense_sc = H_dense + features_full
                H_dense = torch.einsum("bijk,il->bljk", H_dense_sc, self.weights_sc)
                out, features_full, density_matrix = self.implementation.apply_matrix_function(
                    H_dense, ptr, fermi_level
                )
        else:
            # Standard forward pass
            out, features_full, H_dense, density_matrix = self.implementation(
                node_feats, node_attrs, edge_feats, edge_attrs, edge_index, batch, ptr, matrix_feats, fermi_level
            )
        
        return out, features_full, H_dense, density_matrix


class OffDiagMatrixConstructionBlock(torch.nn.Module):
    """
    Constructs the off-diagonal elements of a matrix.
    
    This block handles the construction of off-diagonal matrix elements
    based on node features, edge features, and edge attributes.
    """
    
    def __init__(
        self,
        node_feats_irreps: o3.Irreps,
        interaction_irreps: o3.Irreps,
        num_features: int,
        num_basis: int,
        num_poles: int,
        sh_irreps: o3.Irreps,
        avg_num_neighbors: float,
        irreps_matrix_basis: o3.Irreps,
        cueq_config: Optional[CuEquivarianceConfig] = None,
    ):
        super().__init__()
        self.node_feats_irreps = node_feats_irreps
        self.avg_num_neighbors = avg_num_neighbors
        self.num_poles = num_poles
        self.num_features = num_features
        self.cueq_config = cueq_config

        # Construct blocks for off-diagonal elements
        self.construct_block_off = construct_blocks_off(irreps_matrix_basis)
        irreps_matrix_block = self.construct_block_off.irreps_matrix_block

        # Set up irreps for matrix representation
        irreps_matrix = o3.Irreps(
            (num_features * irreps_matrix_block)
            .sort()
            .irreps.simplify()
        )

        # Set up tensor product operations for message passing
        irreps_mid_mid, instructions = tp_out_irreps_with_instructions(
            interaction_irreps,
            self.node_feats_irreps,
            irreps_matrix,
        )

        irreps_mid, instructions_sh = tp_out_irreps_with_instructions(
            self.node_feats_irreps,
            sh_irreps,
            interaction_irreps,
        )

        # Tensor Products for interaction
        self.conv_tp_sh = TensorProduct(
            self.node_feats_irreps,
            sh_irreps,
            irreps_mid,
            instructions=instructions_sh,
            shared_weights=False,
            internal_weights=False,
            cueq_config=cueq_config,
        )

        self.linear_mid = Linear(
            irreps_mid.simplify(),
            interaction_irreps,
            internal_weights=True,
            shared_weights=True,
            cueq_config=cueq_config,
        )

        self.conv_tp = TensorProduct(
            interaction_irreps,
            self.node_feats_irreps,
            irreps_mid_mid,
            instructions=instructions,
            shared_weights=True,
            internal_weights=True,
            cueq_config=cueq_config,
        )

        # Edge features MLP
        self.edge_feats_mlp_off = nn.FullyConnectedNet(
            [num_basis] + 3 * [64] + [self.conv_tp_sh.weight_numel],
            torch.nn.functional.silu,
        )

        # Output linear layer
        irreps_mid_mid = irreps_mid_mid.simplify()
        self.linear_tp_off_out = Linear(
            irreps_mid_mid, 
            irreps_matrix,
            cueq_config=cueq_config,
        )
        
        # Reshape and normalization
        self.reshape = reshape_irreps_blocks(irreps_matrix, num_features)
        self.batch_norm = nn.BatchNorm(
            irreps_matrix, 
            eps=1e-16, 
            momentum=0.9, 
            affine=True, 
            reduce='mean', 
            instance=False, 
            normalization='component'
        )

    def forward(
        self, 
        node_feats: torch.Tensor, 
        edge_feats: torch.Tensor, 
        edge_attrs: torch.Tensor, 
        edge_index: torch.Tensor, 
        batch: torch.Tensor
    ) -> torch.Tensor:
        """
        Construct off-diagonal elements of the matrix.
        
        Args:
            node_feats: Node features
            edge_feats: Edge features
            edge_attrs: Edge attributes
            edge_index: Edge indices
            batch: Batch indices
            
        Returns:
            H: Off-diagonal element matrix
        """
        # Filter edges to avoid double-counting
        mask_edge_index = (edge_index[0, :] < edge_index[1, :])
        filtered_edges = edge_index[:, mask_edge_index]
        sender, receiver = filtered_edges[0], filtered_edges[1]
        
        # Process edge features
        edge_feats_weights_off = self.edge_feats_mlp_off(edge_feats[mask_edge_index, :])
        
        # Message passing operations
        message = self.conv_tp_sh(
            node_feats[sender], 
            edge_attrs[mask_edge_index, :], 
            edge_feats_weights_off
        )
        message = self.linear_mid(message)
        symmetric_features = self.conv_tp(message, node_feats[receiver])
        
        # Apply batch normalization and reshape
        symmetric_features = self.reshape(
            self.batch_norm(self.linear_tp_off_out(symmetric_features))
        )
        
        # Construct off-diagonal blocks
        H = self.construct_block_off(symmetric_features)
        
        # Convert to dense adjacency matrix
        H_dense = to_dense_adj(edge_index=filtered_edges, batch=batch, edge_attr=H)
        
        # Reshape to proper dimensions
        H_dense = H_dense.permute(0, 3, 1, 4, 2, 5).reshape(
            H_dense.shape[0], 
            H_dense.shape[3], 
            H_dense.shape[1] * H_dense.shape[4], 
            H_dense.shape[2] * H_dense.shape[5]
        )
        
        # Make symmetric
        H_dense = H_dense + H_dense.transpose(-1, -2)
        
        # Expand for multiple poles
        H_dense = H_dense.unsqueeze(2).repeat(1, 1, self.num_poles, 1, 1)
        
        # Add batch dimension for k-points
        return H_dense.unsqueeze(1)


class DiagMatrixConstructionBlock(torch.nn.Module):
    """
    Constructs the diagonal elements of a matrix.
    
    This block handles the construction of diagonal matrix elements
    based on node features and attributes.
    """
    
    def __init__(
        self,
        node_feats_irreps: o3.Irreps,
        num_features: int,
        num_poles: int,
        irreps_matrix_basis: o3.Irreps,
        num_elements: int,
        cueq_config: Optional[CuEquivarianceConfig] = None,
    ):
        super().__init__()
        self.node_feats_irreps = node_feats_irreps
        self.num_poles = num_poles
        self.num_elements = num_elements
        self.num_features = num_features
        self.cueq_config = cueq_config

        # Linear transformation for node features
        self.linear_diag = Linear(
            self.node_feats_irreps,
            self.node_feats_irreps,
            internal_weights=True,
            shared_weights=True,
            cueq_config=cueq_config,
        )

        # Set up blocks for diagonal elements
        self.construct_block_diag = construct_blocks_diag(irreps_matrix_basis)
        self.irreps_matrix_block = self.construct_block_diag.irreps_matrix_block
        
        # Define irreps for matrix representation
        irreps_matrix = o3.Irreps(
            (num_features * self.irreps_matrix_block)
            .sort()
            .irreps.simplify()
        )

        # Instructions for tensor product
        irreps_mid, instructions = tp_out_irreps_with_instructions(
            self.node_feats_irreps,
            self.node_feats_irreps,
            irreps_matrix,
        )
        
        # Tensor product for diagonal elements
        self.conv_tp_diag = TensorProduct(
            self.node_feats_irreps,
            self.node_feats_irreps,
            irreps_mid,
            instructions=instructions,
            shared_weights=True,
            internal_weights=True,
            cueq_config=cueq_config,
        )

        # Output linear layer
        irreps_mid = irreps_mid.simplify()
        self.linear_tp_diag_out = Linear(
            irreps_mid, 
            irreps_matrix,
            cueq_config=cueq_config,
        )
        
        # Reshape and normalization
        self.reshape = reshape_irreps_blocks(irreps_matrix, num_features)
        self.batch_norm = nn.BatchNorm(
            irreps_matrix, 
            eps=1e-16, 
            momentum=0.9, 
            affine=True, 
            reduce='mean', 
            instance=False, 
            normalization='component'
        )

        # Optional orbital energies
        self.orbital_energies = torch.nn.Parameter(
            torch.randn(num_elements, self.irreps_matrix_block.num_irreps)
        )
        self.irreps_matrix = irreps_matrix

    def forward(
        self, 
        node_feats: torch.Tensor, 
        node_attrs: torch.Tensor, 
        batch: torch.Tensor
    ) -> torch.Tensor:
        """
        Construct diagonal elements of the matrix.
        
        Args:
            node_feats: Node features
            node_attrs: Node attributes
            batch: Batch indices
            
        Returns:
            diag_H: Diagonal element matrix
        """
        # Apply linear transformation
        node_feats_diag = self.linear_diag(node_feats)
        
        # Apply tensor product
        diag_H = self.conv_tp_diag(node_feats_diag, node_feats_diag)
        
        # Apply batch normalization and reshape
        diag_H = self.reshape(self.batch_norm(self.linear_tp_diag_out(diag_H)))
        
        # Construct diagonal blocks
        diag_H = self.construct_block_diag(diag_H).repeat(1, self.num_poles, 1, 1)
        
        # Convert to dense batch
        diag_H = to_dense_batch(diag_H, batch)[0]
        
        # Reshape to proper dimensions
        diag_H = diag_H.reshape(
            diag_H.shape[0], 
            diag_H.shape[1], 
            self.num_features, 
            self.num_poles, 
            diag_H.shape[-2], 
            diag_H.shape[-1]
        )
        
        # Permute dimensions for compatibility with OffDiagMatrixConstructionBlock
        return diag_H.permute(0, 2, 3, 1, 4, 5).unsqueeze(1)


def low_rank_eigen_svd(A: torch.Tensor, q: int = 10, niter: int = 2) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Compute low-rank eigendecomposition using SVD.
    
    Args:
        A: Input matrix
        q: Number of eigenvectors to compute
        niter: Number of iterations for SVD
        
    Returns:
        eigenvectors: Low-rank eigenvectors
        eigenvalues: Corresponding eigenvalues
    """
    torch.manual_seed(0)  # for reproducibility
    eigenvectors, svd, eigenvectors_ = torch.svd_lowrank(A, q=q, niter=niter)
    eigenvalues = torch.einsum(
        "...j,...ij->...i", 
        eigenvectors[:,:,0,:], 
        torch.diag_embed(svd)
    ) / eigenvectors_[:,:,0,:]
    return eigenvectors, eigenvalues.permute(0, 2, 1)


class EigenvalueBatchNorm(torch.nn.Module):
    """
    Batch normalization for eigenvalues.
    
    This layer normalizes the eigenvalues of a matrix across the batch dimension.
    """
    
    def __init__(
        self, 
        num_features: int, 
        eps: float = 1e-16, 
        momentum: float = 0.997, 
        starting_momentum: float = 0.8, 
        warmup_steps: int = 100, 
        using_moving_average: bool = True, 
        random_weights: bool = True
    ):
        super().__init__()
        self.eps = eps
        self.momentum = momentum
        self.starting_momentum = starting_momentum
        self.warmup_steps = warmup_steps
        self.using_moving_average = using_moving_average
        self.num_features = num_features
        self.random_weights = random_weights
        self.steps = 0
        
        # Initialize parameters
        if random_weights:
            weight_exp = torch.randn(1, num_features, 1, 1)
            weight_bias = torch.zeros(1, num_features, 1, 1)
            weight = torch.ones(1, num_features, 1, 1)
            bias = torch.randn(1, num_features, 1)
        else:
            weight = torch.ones(1, num_features, 1, 1)
            bias = torch.zeros(1, num_features, 1)

        # Register parameters
        self.weight = torch.nn.Parameter(weight)
        self.weight_exp = torch.nn.Parameter(weight_exp)
        self.weight_bias = torch.nn.Parameter(weight_bias)
        self.bias = torch.nn.Parameter(bias)
        
        # Register buffers for running statistics
        self.register_buffer("running_mean", torch.zeros(num_features))
        self.register_buffer("running_var", torch.ones(num_features))
        
        self.reset_parameters()

    def reset_parameters(self):
        """Reset the running statistics."""
        self.running_mean.zero_()
        self.running_var.fill_(1)
        self.steps = 0

    def _check_input_dim(self, input: torch.Tensor):
        """Check that input has the correct dimensions."""
        if input.dim() != 4:
            raise ValueError(f"expected input 4 dimensions (got {input.dim()}D input)")
        if input.shape[1] != self.num_features:
            raise ValueError(f"expected num_features to be {self.num_features}, got {input.shape[1]}")

    def _mean_and_variance_trace(self, matrix: torch.Tensor, mask: torch.Tensor):
        """Compute mean and variance using trace method."""
        # Count non-zero elements in mask
        n = torch.einsum('bfii->bf', mask)
        n2 = torch.clamp(n-1, 1)  # Clamp at n - 1 = 1 to avoid division by zero
        
        # Compute matrix powers and traces
        matrix_squared = torch.linalg.matrix_power(matrix, 2) * mask
        trace = torch.einsum('bfii->bf', matrix * mask)
        trace_square = torch.einsum('bfii->bf', matrix_squared * mask)
        
        # Compute mean and variance
        mean = trace / n
        variance = trace_square / n2 - trace ** 2 / (n * n2)
        
        return mean.mean(0), variance.mean(0)

    def _reformat_mask(self, mask: torch.Tensor):
        """Reformat mask tensor to match input shape."""
        mask = mask[:, None, :, None] * mask[:, None, None, :]
        mask = mask.expand(-1, self.num_features, -1, -1)
        return mask

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None):
        """
        Apply normalization to input tensor.
        
        Args:
            x: Input tensor [batch_size, num_features, N, N]
            mask: Optional mask tensor [batch_size, N]
            
        Returns:
            Normalized tensor
        """
        self._check_input_dim(x)
        
        # Create or reformat mask
        if mask is None:
            mask = torch.ones(x.shape, device=x.device)
        else:
            mask = self._reformat_mask(mask)

        # Update statistics during training
        if self.training:
            mean, variance = self._mean_and_variance_trace(x, mask)
            
            if self.using_moving_average:
                # Apply momentum warmup
                if self.steps < self.warmup_steps:
                    beta = self.steps / self.warmup_steps
                    momentum = self.momentum * beta + self.starting_momentum * (1 - beta)
                else:
                    momentum = self.momentum
                
                # Update running statistics with momentum
                self.running_mean.mul_(momentum)
                self.running_mean.add_((1 - momentum) * mean.data)
                self.running_var.mul_(momentum)
                self.running_var.add_((1 - momentum) * variance.data)
            else:
                # Update running statistics without momentum
                self.running_mean.add_(mean.data)
                self.running_var.add_(variance.data)
                
            self.steps += 1
            
        # Use running statistics
        m = torch.autograd.Variable(self.running_mean)
        v = torch.autograd.Variable(self.running_var)

        # Create diagonal matrix of means and apply centering
        m_t = torch.diag_embed(
            m[None, :, None].expand_as(x[..., 0]), 
            offset=0, 
            dim1=-2, 
            dim2=-1
        )
        x_centered = (x - m_t) * mask
        
        # Normalize centered tensor
        x_normalized = x_centered / ((v[None, :, None, None].expand_as(x)).sqrt() + self.eps)
        
        # Apply learned scale and shift
        return (
            x_normalized * (self.weight * torch.exp(self.weight_exp) + self.weight_bias) + 
            torch.diag_embed(self.bias.expand_as(x[..., 0]), offset=0, dim1=-2, dim2=-1)
        )


class EigenvalueLayerNorm(torch.nn.Module):
    """
    Layer normalization for eigenvalues.
    
    This layer normalizes the eigenvalues of a matrix within each sample.
    """
    
    def __init__(
        self, 
        num_features: int, 
        eps: float = 1e-15, 
        random_weights: bool = True
    ):
        super().__init__()
        self.eps = eps
        self.num_features = num_features

        # Initialize parameters
        if random_weights:
            weight_exp = torch.randn(1, num_features, 1, 1)
            weight_bias = torch.zeros(1, num_features, 1, 1)
            weight = torch.ones(1, num_features, 1, 1)
            bias = torch.randn(1, num_features, 1)
        else:
            weight = torch.ones(1, num_features, 1, 1)
            bias = torch.zeros(1, num_features, 1)

        # Register parameters
        self.weight = torch.nn.Parameter(weight)
        self.weight_exp = torch.nn.Parameter(weight_exp)
        self.weight_bias = torch.nn.Parameter(weight_bias)
        self.bias = torch.nn.Parameter(bias)

    def _check_input_dim(self, input: torch.Tensor):
        """Check that input has the correct dimensions."""
        if input.dim() != 4:
            raise ValueError(f"expected input 4 dimensions (got {input.dim()}D input)")
        if input.shape[1] != self.num_features:
            raise ValueError(f"expected num_features to be {self.num_features}, got {input.shape[1]}")

    def _mean_and_variance_trace(self, matrix: torch.Tensor, mask: torch.Tensor):
        """Compute mean and variance using trace method."""
        # Count non-zero elements in mask
        n = torch.einsum('bfii->bf', mask)
        n2 = torch.clamp(n - 1, 1)  # Clamp at n - 1 = 1 to avoid division by zero
        
        # Compute matrix powers and traces
        matrix_squared = torch.linalg.matrix_power(matrix, 2) * mask
        trace = torch.einsum('bfii->bf', matrix * mask)
        trace_square = torch.einsum('bfii->bf', matrix_squared * mask)
        
        # Compute mean and variance
        mean = trace / n
        variance = trace_square / n2 - trace ** 2 / (n * n2)
        
        return mean, variance

    def _reformat_mask(self, mask: torch.Tensor):
        """Reformat mask tensor to match input shape."""
        mask = mask[:, None, :, None] * mask[:, None, None, :]
        mask = mask.expand(-1, self.num_features, -1, -1)
        return mask

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None):
        """
        Apply normalization to input tensor.
        
        Args:
            x: Input tensor [batch_size, num_features, N, N]
            mask: Optional mask tensor [batch_size, N]
            
        Returns:
            Normalized tensor
        """
        self._check_input_dim(x)
        
        # Create or reformat mask
        if mask is None:
            mask = torch.ones(x.shape)
        else:
            mask = self._reformat_mask(mask)

        # Compute statistics for this batch
        mean, variance = self._mean_and_variance_trace(x, mask)
        
        # Expand dimensions to match x
        m = mean.unsqueeze(1).unsqueeze(-1)
        v = variance.unsqueeze(1).unsqueeze(-1).unsqueeze(-1)
        
        # Create diagonal matrix of means and apply centering
        m_t = torch.diag_embed(
            m.expand_as(x[..., 0]), 
            offset=0, 
            dim1=-2, 
            dim2=-1
        )
        x_centered = (x - m_t) * mask
        
        # Normalize centered tensor
        x_normalized = x_centered / (v.expand_as(x) + self.eps).sqrt()
        
        # Apply learned scale and shift
        return (
            x_normalized * (self.weight * torch.exp(self.weight_exp) + self.weight_bias) + 
            torch.diag_embed(self.bias.expand_as(x[..., 0]), offset=0, dim1=-2, dim2=-1)
        )
    
def extract_sum_of_diagonals(tensor: torch.Tensor, irreps_dim: int):
    batch_size = tensor.size(0)
    num_channels = tensor.size(1)
    n = tensor.size(-1) // irreps_dim
    tensor = tensor.view(batch_size * num_channels, n, irreps_dim, n, irreps_dim)
    tensor = tensor.permute(0, 1, 3, 2, 4)
    diagonals = tensor.diagonal(dim1=-1, dim2=-2)
    sum_of_diagonals = diagonals.sum(dim=-1).diagonal(dim1=-1, dim2=-2)
    return sum_of_diagonals.view(batch_size, num_channels, -1).permute(0, 2, 1)

@compile_mode("script")
class extract_blocks(torch.nn.Module):
    def __init__(self, irreps: o3.Irreps) -> None:
        super().__init__()
        self.irreps = irreps
        tp_basis = o3.ReducedTensorProducts("ij=ji", i=self.irreps, j=self.irreps)
        self.irreps_out = tp_basis.irreps_out
        self.register_buffer("change_of_basis", tp_basis.change_of_basis)

    def forward(self, H: torch.Tensor) -> torch.Tensor:
        n = H.shape[-1] // self.irreps.dim
        irreps_dim = self.irreps.dim
        mask = torch.eye(n, dtype=torch.bool).repeat_interleave(irreps_dim, dim=0).repeat_interleave(irreps_dim, dim=1)
        block = H[:, :, mask].reshape(H.shape[0], H.shape[1], n, irreps_dim, irreps_dim)
        extract = torch.einsum('ikj,...kj->...i', self.change_of_basis, block)
        return extract.permute(0,2,1,3)


@compile_mode("script")
class fill_blocks(torch.nn.Module):
    def __init__(self, irreps_matrix_basis: o3.Irreps) -> None:
        super().__init__()
        self.irreps_matrix_basis = irreps_matrix_basis
    def forward(self, H: torch.Tensor, diag: torch.Tensor) -> torch.Tensor:
        diag_shape = diag.shape	
        diag = diag.reshape(*diag_shape[:-3], -1)
        irreps_dim = self.irreps_matrix_basis.dim
        n = H.shape[-1] // irreps_dim
        mask = torch.eye(n, dtype=torch.bool).repeat_interleave(irreps_dim, dim=0).repeat_interleave(irreps_dim, dim=1)
        H[..., mask] += diag
        return H
    

class construct_blocks_diag(torch.nn.Module):
    def __init__(
        self,
        matrix_features: o3.Irreps,
    ):
        super().__init__()
        self.matrix_lmax = matrix_features.lmax
        self.irreps_slices = matrix_features.slices()
        tp_basis = o3.ReducedTensorProducts("ij=ji", i=matrix_features)
        self.irreps_matrix_block = tp_basis.irreps_out
        self.register_buffer("change_of_basis", tp_basis.change_of_basis)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        H = torch.einsum('ikj,...i->...kj', self.change_of_basis, x)
        return H

class construct_blocks_off(torch.nn.Module):
    def __init__(
        self,
        matrix_features: o3.Irreps,
    ):
        super().__init__()
        self.matrix_lmax = matrix_features.lmax
        self.irreps_slices = matrix_features.slices()
        tp_basis = o3.ReducedTensorProducts("ij=ij", i=matrix_features, j=matrix_features)
        self.irreps_matrix_block = tp_basis.irreps_out
        self.register_buffer("change_of_basis", tp_basis.change_of_basis)
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        H = torch.einsum('ikj,...i->...kj', self.change_of_basis, x)
        return H
    
class unreshape_irreps_blocks(torch.nn.Module):
    def __init__(self, irreps: o3.Irreps) -> None:
        super().__init__()
        self.irreps = o3.Irreps(irreps)
        self.irreps_slices = self.irreps.slices()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_sliced = [x[:, :, s].reshape(x.shape[0], -1) for s in self.irreps_slices]
        return torch.cat(x_sliced, dim=-1)


class reshape_irreps_blocks(torch.nn.Module):
    def __init__(self, irreps: o3.Irreps, num_features: int = 1) -> None:
        super().__init__()
        self.irreps = o3.Irreps(irreps)
        self.irreps_slices = self.irreps.slices()
        self.num_features = num_features
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_sliced = [x[:, s].reshape(x.shape[0], self.num_features, -1) for s in self.irreps_slices]
        return torch.cat(x_sliced, dim=-1)